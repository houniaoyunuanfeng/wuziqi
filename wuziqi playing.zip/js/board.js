class Board {
    constructor(canvasId, size = 15) {
        this.canvas = document.getElementById(canvasId);
        this.ctx = this.canvas.getContext('2d');
        this.size = size; // 棋盘尺寸，标准五子棋为15×15
        this.cellSize = 30; // 每个格子的大小
        this.padding = 20; // 棋盘边缘填充
        
        // 设置画布尺寸，并考虑设备缩放比，保证清晰度
        const scaleFactor = window.devicePixelRatio || 1;
        this.canvas.width = (this.size * this.cellSize + this.padding * 2) * scaleFactor;
        this.canvas.height = (this.size * this.cellSize + this.padding * 2) * scaleFactor;
        
        // 设置Canvas显示尺寸
        this.canvas.style.width = `${this.size * this.cellSize + this.padding * 2}px`;
        this.canvas.style.height = `${this.size * this.cellSize + this.padding * 2}px`;
        
        // 缩放画布以匹配设备像素比
        this.ctx.scale(scaleFactor, scaleFactor);
        
        // 棋盘状态, 0: 空, 1: 黑子, 2: 白子
        this.grid = Array(this.size).fill().map(() => Array(this.size).fill(0));
        
        // 下棋历史记录，用于悔棋和标记步数
        this.history = [];
        
        // 绑定事件监听器
        this.canvas.addEventListener('click', this.handleClick.bind(this));
        
        // 初始化回调函数
        this.onPlaceStone = null;
        
        // 音效回调函数
        this.onPlayStoneSound = null;

        // 初始化声音管理器
        this.soundManager = new SoundManager();

        // 绘制初始棋盘
        this.drawBoard();
        
        // 优化性能: 减少刷新次数
        this.pendingRender = false;
    }
    
    // 绘制棋盘
    drawBoard() {
        if (this.pendingRender) return;
        
        this.pendingRender = true;
        
        // 使用requestAnimationFrame优化渲染性能
        requestAnimationFrame(() => {
            console.log("绘制棋盘底图");
            
            // 绘制棋盘背景
            this.ctx.fillStyle = '#deb887'; // 棋盘背景色
            this.ctx.fillRect(0, 0, this.canvas.width / window.devicePixelRatio, this.canvas.height / window.devicePixelRatio);
            
            // 绘制网格线
            this.ctx.strokeStyle = '#000';
            this.ctx.lineWidth = 1;
            
            for (let i = 0; i < this.size; i++) {
                // 水平线
                this.ctx.beginPath();
                this.ctx.moveTo(this.padding, this.padding + i * this.cellSize);
                this.ctx.lineTo(this.padding + (this.size-1) * this.cellSize, this.padding + i * this.cellSize);
                this.ctx.stroke();
                
                // 垂直线
                this.ctx.beginPath();
                this.ctx.moveTo(this.padding + i * this.cellSize, this.padding);
                this.ctx.lineTo(this.padding + i * this.cellSize, this.padding + (this.size-1) * this.cellSize);
                this.ctx.stroke();
            }
            
            // 绘制五个星位点
            const starPoints = [
                {x: 3, y: 3},
                {x: 3, y: this.size - 4},
                {x: this.size - 4, y: 3},
                {x: this.size - 4, y: this.size - 4},
                {x: Math.floor(this.size / 2), y: Math.floor(this.size / 2)}
            ];
            
            starPoints.forEach(point => {
                this.ctx.beginPath();
                this.ctx.arc(
                    this.padding + point.x * this.cellSize,
                    this.padding + point.y * this.cellSize,
                    3, 0, Math.PI * 2
                );
                this.ctx.fillStyle = '#000';
                this.ctx.fill();
            });
            
            this.pendingRender = false;
        });
    }
    
    // 绘制棋子
    drawStone(x, y, type, moveNumber = null) {
        const xPos = this.padding + x * this.cellSize;
        const yPos = this.padding + y * this.cellSize;
        const radius = this.cellSize / 2 - 2;
        
        this.ctx.beginPath();
        this.ctx.arc(xPos, yPos, radius, 0, Math.PI * 2);
        
        // 创建棋子渐变
        const gradient = this.ctx.createRadialGradient(
            xPos - radius / 3, yPos - radius / 3, radius / 8,
            xPos, yPos, radius
        );
        
        if (type === 1) { // 黑子
            gradient.addColorStop(0, '#666');
            gradient.addColorStop(1, '#000');
        } else { // 白子
            gradient.addColorStop(0, '#fff');
            gradient.addColorStop(1, '#ccc');
        }
        
        this.ctx.fillStyle = gradient;
        this.ctx.fill();
        this.ctx.strokeStyle = type === 1 ? '#000' : '#999';
        this.ctx.lineWidth = 1;
        this.ctx.stroke();
        
        // 如果提供了步数，直接在棋子上绘制步数
        if (moveNumber !== null) {
            // 设置文本样式
            this.ctx.font = 'bold 14px Arial';
            this.ctx.textAlign = 'center';
            this.ctx.textBaseline = 'middle';
            
            // 黑子白字，白子黑字
            this.ctx.fillStyle = type === 1 ? '#fff' : '#000';
            this.ctx.fillText(moveNumber.toString(), xPos, yPos);
        }
    }
    
    // 处理点击事件
    handleClick(e) {
        if (!this.onPlaceStone) return;
        
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left) * (this.canvas.width / rect.width / window.devicePixelRatio);
        const y = (e.clientY - rect.top) * (this.canvas.height / rect.height / window.devicePixelRatio);
        
        // 计算点击的格子
        const gridX = Math.round((x - this.padding) / this.cellSize);
        const gridY = Math.round((y - this.padding) / this.cellSize);
        
        // 检查是否在有效范围内
        if (gridX >= 0 && gridX < this.size && gridY >= 0 && gridY < this.size) {
            // 检查该位置是否已有棋子
            if (this.grid[gridY][gridX] === 0) {
                this.onPlaceStone(gridX, gridY);
            }
        }
    }
    
    // 放置棋子
    placeStone(x, y, type) {
        console.log(`尝试在(${x}, ${y})放置类型${type}的棋子`);
        
        if (x < 0 || x >= this.size || y < 0 || y >= this.size) {
            console.error(`位置(${x}, ${y})超出棋盘范围`);
            return false;
        }
        
        if (this.grid[y][x] !== 0) {
            console.error(`位置(${x}, ${y})已有棋子`);
            return false;
        }
        
        this.grid[y][x] = type;
        this.drawStone(x, y, type, this.history.length + 1);
        this.history.push({x, y, type});
        
        console.log(`成功放置棋子，当前历史记录长度: ${this.history.length}`);
        
        // 播放落子音效
        if (this.onPlayStoneSound) {
            this.onPlayStoneSound();
        }
        
        return true;
    }
    
    // 悔棋
    undo() {
        console.log("执行Board.undo方法，当前历史记录长度:", this.history.length);
        
        if (this.history.length === 0) {
            console.log("没有历史记录可以悔棋");
            return false;
        }
        
        const lastMove = this.history.pop();
        console.log("取出最后一步:", lastMove);
        
        if (lastMove && typeof lastMove.x === 'number' && typeof lastMove.y === 'number' && 
            lastMove.x >= 0 && lastMove.y >= 0 && 
            lastMove.x < this.size && lastMove.y < this.size) {
            console.log(`从棋盘[${lastMove.y}][${lastMove.x}]移除棋子`);
            this.grid[lastMove.y][lastMove.x] = 0;
            
            console.log("悔棋成功，剩余历史记录:", this.history.length);
            return true;
        } else {
            // 如果历史记录有错，修复历史并返回失败
            console.error('历史记录数据无效，无法悔棋:', lastMove);
            if (lastMove) {
                this.history.push(lastMove); // 恢复历史记录
            }
            return false;
        }
    }
    
    // 检查是否有玩家胜利
    checkWin(x, y, type) {
        const directions = [
            {x: 1, y: 0},  // 水平
            {x: 0, y: 1},  // 垂直
            {x: 1, y: 1},  // 右下
            {x: 1, y: -1}  // 右上
        ];
        
        for (const dir of directions) {
            let count = 1;
            
            // 正方向
            for (let i = 1; i <= 4; i++) {
                const nx = x + dir.x * i;
                const ny = y + dir.y * i;
                
                if (nx < 0 || nx >= this.size || ny < 0 || ny >= this.size || this.grid[ny][nx] !== type) {
                    break;
                }
                
                count++;
            }
            
            // 反方向
            for (let i = 1; i <= 4; i++) {
                const nx = x - dir.x * i;
                const ny = y - dir.y * i;
                
                if (nx < 0 || nx >= this.size || ny < 0 || ny >= this.size || this.grid[ny][nx] !== type) {
                    break;
                }
                
                count++;
            }
            
            if (count >= 5) {
                return true;
            }
        }
        
        return false;
    }
    
    // 重置棋盘
    reset() {
        this.grid = Array(this.size).fill().map(() => Array(this.size).fill(0));
        this.history = [];
        this.drawBoard();
    }
    
    // 获取指定位置的棋子类型
    getStone(x, y) {
        if (x < 0 || x >= this.size || y < 0 || y >= this.size) {
            return -1; // 超出边界
        }
        return this.grid[y][x];
    }
    
    // 加载指定局面（用于残局挑战）
    loadPosition(positionData) {
        // 重置棋盘
        this.reset();
        
        // 应用位置数据
        if (Array.isArray(positionData) && positionData.length === this.size) {
            for (let y = 0; y < this.size; y++) {
                for (let x = 0; x < this.size; x++) {
                    const stoneType = positionData[y][x];
                    if (stoneType === 1 || stoneType === 2) {
                        this.grid[y][x] = stoneType;
                        this.history.push({x, y, type: stoneType});
                    }
                }
            }
            
            this.drawBoard();
            
            // 绘制所有棋子
            this.history.forEach((move, index) => {
                this.drawStone(move.x, move.y, move.type, index + 1);
            });
            
            // 高亮最后一步
            this.highlightLastMove();
        }
    }
    
    // 高亮显示最后一步棋
    highlightLastMove() {
        if (this.history.length === 0) return;
        
        const lastMove = this.history[this.history.length - 1];
        const xPos = this.padding + lastMove.x * this.cellSize;
        const yPos = this.padding + lastMove.y * this.cellSize;
        const radius = this.cellSize / 2;
        
        // 绘制高亮边框
        this.ctx.beginPath();
        this.ctx.arc(xPos, yPos, radius + 2, 0, Math.PI * 2);
        this.ctx.strokeStyle = 'rgba(255, 100, 0, 0.8)';
        this.ctx.lineWidth = 2;
        this.ctx.stroke();
    }
    
    // 开始新游戏，同时播放背景音乐
    startNewGame() {
        this.reset();
        this.soundManager.playBgMusic();
    }
    
    // 停止游戏，同时暂停背景音乐
    stopGame() {
        this.soundManager.pauseBgMusic();
    }
    
    // 声音控制方法
    toggleMute() {
        return this.soundManager.toggleMute();
    }
    
    setMute(muted) {
        this.soundManager.setMute(muted);
    }
    
    setBgMusicVolume(volume) {
        this.soundManager.setBgMusicVolume(volume);
    }
    
    setSfxVolume(volume) {
        this.soundManager.setSfxVolume(volume);
    }
} 