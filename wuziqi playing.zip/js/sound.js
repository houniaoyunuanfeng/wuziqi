/**
 * 音效管理类
 * 负责管理游戏的音频，包括背景音乐和落子音效
 */
class SoundManager {
    constructor() {
        // 获取音频元素
        this.bgMusic = document.getElementById('bg-music');
        this.stoneSound = document.getElementById('stone-sound');
        
        // 获取设置面板的开关
        this.bgMusicToggle = document.getElementById('bg-music-toggle');
        this.soundEffectToggle = document.getElementById('sound-effect-toggle');
        
        // 设置音量
        this.bgMusic.volume = 0.5;
        this.stoneSound.volume = 0.8;
        
        // 从本地存储加载音频设置，如果不存在则使用默认设置
        this.bgMusicEnabled = localStorage.getItem('bgMusicEnabled') !== 'false';
        this.soundEffectEnabled = localStorage.getItem('soundEffectEnabled') !== 'false';
        
        // 更新切换开关状态
        this.bgMusicToggle.checked = this.bgMusicEnabled;
        this.soundEffectToggle.checked = this.soundEffectEnabled;
        
        // 绑定事件监听器
        this.bgMusicToggle.addEventListener('change', this.toggleBgMusic.bind(this));
        this.soundEffectToggle.addEventListener('change', this.toggleSoundEffect.bind(this));
        
        // 初始化背景音乐（如果启用）
        this.initBgMusic();
        
        // 处理页面可见性变化
        document.addEventListener('visibilitychange', () => {
            if (this.bgMusicEnabled) {
                if (document.hidden) {
                    this.bgMusic.pause();
                } else {
                    this.bgMusic.play().catch(error => console.log('Auto-play prevented: ', error));
                }
            }
        });
    }
    
    // 初始化背景音乐
    initBgMusic() {
        if (this.bgMusicEnabled) {
            // 尝试播放背景音乐，处理自动播放限制
            this.bgMusic.play().catch(error => {
                console.log('Auto-play prevented: ', error);
                // 添加用户交互监听，以便之后可以播放
                const playOnInteraction = () => {
                    this.bgMusic.play().catch(e => console.log('Play failed: ', e));
                    document.removeEventListener('click', playOnInteraction);
                };
                document.addEventListener('click', playOnInteraction);
            });
        }
    }
    
    // 切换背景音乐
    toggleBgMusic() {
        this.bgMusicEnabled = this.bgMusicToggle.checked;
        localStorage.setItem('bgMusicEnabled', this.bgMusicEnabled);
        
        if (this.bgMusicEnabled) {
            this.bgMusic.play().catch(error => console.log('Play failed: ', error));
        } else {
            this.bgMusic.pause();
        }
    }
    
    // 切换落子音效
    toggleSoundEffect() {
        this.soundEffectEnabled = this.soundEffectToggle.checked;
        localStorage.setItem('soundEffectEnabled', this.soundEffectEnabled);
    }
    
    // 播放落子音效
    playStoneSound() {
        if (!this.soundEffectEnabled) return;
        
        // 重置音效，允许多次快速播放
        this.stoneSound.currentTime = 0;
        this.stoneSound.play().catch(error => console.log('Sound effect failed: ', error));
    }
} 