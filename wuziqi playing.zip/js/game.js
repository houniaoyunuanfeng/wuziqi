class Game {
    constructor(boardId, aiLevel = 1) {
        this.board = new Board(boardId, 15);
        this.currentPlayer = 1; // 1: 黑子，2: 白子
        this.gameOver = false;
        this.aiEnabled = true;
        this.aiLevel = aiLevel;
        this.aiPlayer = 2; // AI默认使用白子
        this.aiThinking = false;
        this.started = false;
        
        // 悔棋次数限制
        this.maxUndoCount = 3;
        this.undoCount = 0;
        
        // 回调函数
        this.onGameOver = null;
        
        // 初始化计时器
        this.timerEnabled = true; // 默认启用计时器
        this.timeLimit = 30; // 默认30秒
        this.blackTimeRemaining = this.timeLimit;
        this.whiteTimeRemaining = this.timeLimit;
        this.timerInterval = null;
        this.timerDisplay = {
            black: document.getElementById('black-timer'),
            white: document.getElementById('white-timer')
        };
        
        // 初始化游戏信息显示
        this.gameInfo = document.getElementById('player-turn');
        
        // 初始化音效管理器
        this.soundManager = new SoundManager();
        
        // 将落子音效连接到棋盘
        this.board.onPlayStoneSound = () => this.soundManager.playStoneSound();
        
        // 设置回调函数
        this.board.onPlaceStone = (x, y) => this.makeMove(x, y);
        
        this.updateTimerDisplay();
    }
    
    startGame() {
        this.board.reset();
        this.currentPlayer = 1;
        this.gameOver = false;
        this.started = true;
        this.undoCount = 0; // 重置悔棋次数
        
        // 更新悔棋按钮状态
        this.updateUndoButton();
        
        // 移除之前的游戏结果显示
        const oldOverlay = document.getElementById('game-result-overlay');
        if (oldOverlay) {
            oldOverlay.remove();
        }
        
        // 更新玩家回合显示
        const playerTurnElement = document.getElementById('player-turn');
        if (playerTurnElement) {
            playerTurnElement.textContent = `轮到: ${this.currentPlayer === 1 ? '黑子' : '白子'}`;
        }
        
        // 启动计时器
        if (this.timerEnabled) {
            this.resetTimer();
            this.startTimer();
        }
        
        // 清空并重绘棋盘
        this.redrawBoard();
        
        // 播放背景音乐
        this.soundManager.playBgMusic();
        
        // 如果AI使用黑子，则立即进行AI下棋
        if (this.aiEnabled && this.aiPlayer === this.currentPlayer) {
            this.aiMove();
        }
    }
    
    makeMove(x, y) {
        if (this.gameOver || !this.started || this.aiThinking) return false;
        
        // 检查是否是玩家的回合
        if (this.aiEnabled && this.currentPlayer === this.aiPlayer) return false;
        
        if (this.board.placeStone(x, y, this.currentPlayer)) {
            console.log(`玩家放置棋子在(${x}, ${y})`);
            
            // 检查胜利条件
            if (this.board.checkWin(x, y, this.currentPlayer)) {
                this.endGame(this.currentPlayer);
                return true;
            }
            
            // 检查是否平局（棋盘已满）
            let isBoardFull = true;
            for (let i = 0; i < this.board.size; i++) {
                for (let j = 0; j < this.board.size; j++) {
                    if (this.board.grid[i][j] === 0) {
                        isBoardFull = false;
                        break;
                    }
                }
                if (!isBoardFull) break;
            }
            
            if (isBoardFull) {
                this.endGame(0); // 0表示平局
                return true;
            }
            
            // 更换玩家
            this.switchPlayer();
            
            // 启动计时器
            if (this.timerEnabled) {
                this.resetTimer();
                this.startTimer();
            }
            
            // 如果开启了AI并且现在是AI的回合
            if (this.aiEnabled && this.currentPlayer === this.aiPlayer && !this.gameOver) {
                // 使用requestAnimationFrame和setTimeout组合，确保UI能够更新
                requestAnimationFrame(() => {
                    setTimeout(() => {
                        this.aiMove();
                    }, 50);
                });
            }
            
            return true;
        }
        
        return false;
    }
    
    aiMove() {
        if (this.gameOver || !this.started) return;
        
        this.aiThinking = true;
        
        // 更新UI以指示AI正在思考
        const playerTurnElement = document.getElementById('player-turn');
        if (playerTurnElement) {
            playerTurnElement.textContent = `AI 思考中...`;
        }
        
        // 使用setTimeout并降低延迟，以减少可能的UI阻塞
        setTimeout(() => {
            try {
                const ai = new AI(this.board, this.aiLevel);
                const move = ai.findBestMove(this.aiPlayer);
                
                if (move && !this.gameOver) {
                    if (this.board.placeStone(move.x, move.y, this.currentPlayer)) {
                        console.log(`AI放置棋子在(${move.x}, ${move.y})`);
                        
                        // 检查胜利条件
                        if (this.board.checkWin(move.x, move.y, this.currentPlayer)) {
                            this.endGame(this.currentPlayer);
                        } else {
                            // 检查是否平局（棋盘已满）
                            let isBoardFull = true;
                            for (let i = 0; i < this.board.size; i++) {
                                for (let j = 0; j < this.board.size; j++) {
                                    if (this.board.grid[i][j] === 0) {
                                        isBoardFull = false;
                                        break;
                                    }
                                }
                                if (!isBoardFull) break;
                            }
                            
                            if (isBoardFull) {
                                this.endGame(0); // 0表示平局
                            } else {
                                // 更换玩家
                                this.switchPlayer();
                                
                                // 启动计时器
                                if (this.timerEnabled) {
                                    this.resetTimer();
                                    this.startTimer();
                                }
                            }
                        }
                    }
                }
            } catch (error) {
                console.error('AI 计算过程中出错:', error);
                // 恢复正常状态
                this.switchPlayer();
            } finally {
                this.aiThinking = false;
            }
        }, 100); // 减少AI思考时间以提高响应性
    }
    
    switchPlayer() {
        this.currentPlayer = this.currentPlayer === 1 ? 2 : 1;
        
        // 更新当前玩家指示
        const playerTurnElement = document.getElementById('player-turn');
        if (playerTurnElement) {
            playerTurnElement.textContent = `轮到: ${this.currentPlayer === 1 ? '黑子' : '白子'}`;
        }
        
        // 更新计时器状态
        if (this.timerDisplay.black && this.timerDisplay.white) {
            if (this.currentPlayer === 1) {
                this.timerDisplay.black.classList.add('active');
                this.timerDisplay.white.classList.remove('active');
            } else {
                this.timerDisplay.black.classList.remove('active');
                this.timerDisplay.white.classList.add('active');
            }
        }
    }
    
    endGame(winner) {
        this.gameOver = true;
        
        // 停止计时器
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
        
        // 构建胜利消息
        let message = '';
        
        if (winner === 1) {
            message = '黑方胜利！';
            if (this.aiPlayer === 1) {
                message += '(AI获胜)';
            } else {
                message += '(玩家获胜)';
            }
            this.soundManager.playWinSound();
        } else if (winner === 2) {
            message = '白方胜利！';
            if (this.aiPlayer === 2) {
                message += '(AI获胜)';
            } else {
                message += '(玩家获胜)';
            }
            this.soundManager.playWinSound();
        } else {
            message = '平局！';
            this.soundManager.playDrawSound();
        }
        
        // 更新游戏信息文本
        const playerTurnElement = document.getElementById('player-turn');
        if (playerTurnElement) {
            playerTurnElement.textContent = `游戏结束 - ${message}`;
        }
        
        // 在棋盘上显示游戏结果
        this.showGameResultOverlay(message);
        
        // 触发游戏结束事件
        if (typeof this.onGameOver === 'function') {
            this.onGameOver(winner);
        }
        
        // 显示结果消息弹窗
        alert(message);
    }
    
    // 在棋盘上显示游戏结果
    showGameResultOverlay(message) {
        // 移除可能存在的旧结果层
        const oldOverlay = document.getElementById('game-result-overlay');
        if (oldOverlay) {
            oldOverlay.remove();
        }
        
        // 创建新的结果显示层
        const overlay = document.createElement('div');
        overlay.id = 'game-result-overlay';
        overlay.style.position = 'absolute';
        overlay.style.top = '50%';
        overlay.style.left = '50%';
        overlay.style.transform = 'translate(-50%, -50%)';
        overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
        overlay.style.color = 'white';
        overlay.style.padding = '15px 25px';
        overlay.style.borderRadius = '10px';
        overlay.style.fontSize = '24px';
        overlay.style.fontWeight = 'bold';
        overlay.style.zIndex = '100';
        overlay.style.textAlign = 'center';
        overlay.style.boxShadow = '0 0 20px rgba(255, 255, 255, 0.5)';
        overlay.textContent = message;
        
        // 将结果层添加到棋盘容器
        const boardContainer = document.querySelector('.board-container');
        if (boardContainer) {
            boardContainer.style.position = 'relative'; // 确保定位正确
            boardContainer.appendChild(overlay);
        }
    }
    
    // 设置AI级别
    setAILevel(level) {
        this.aiLevel = level;
    }
    
    // 设置AI玩家
    setAIPlayer(player) {
        this.aiPlayer = player; // 1为黑子，2为白子
    }
    
    // 切换AI玩家
    toggleAIPlayer() {
        this.aiPlayer = this.aiPlayer === 1 ? 2 : 1;
    }
    
    enableTimer(enabled) {
        this.timerEnabled = enabled;
        
        if (enabled) {
            this.resetTimer();
            if (this.started && !this.gameOver) {
                this.startTimer();
            }
        } else {
            if (this.timerInterval) {
                clearInterval(this.timerInterval);
                this.timerInterval = null;
            }
        }
        
        // 更新UI显示
        const timerContainer = document.getElementById('timer-container');
        if (timerContainer) {
            timerContainer.style.display = enabled ? 'flex' : 'none';
        }
    }
    
    setTimeLimit(seconds) {
        this.timeLimit = seconds;
        this.resetTimer();
    }
    
    resetTimer() {
        this.blackTimeRemaining = this.timeLimit;
        this.whiteTimeRemaining = this.timeLimit;
        
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
        
        this.updateTimerDisplay();
    }
    
    startTimer() {
        if (!this.timerEnabled || this.gameOver) return;
        
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
        }
        
        this.timerInterval = setInterval(() => {
            if (this.currentPlayer === 1) {
                this.blackTimeRemaining -= 0.1;
                if (this.blackTimeRemaining <= 0) {
                    this.blackTimeRemaining = 0;
                    this.endGame(2); // 黑方超时，白方胜
                }
            } else {
                this.whiteTimeRemaining -= 0.1;
                if (this.whiteTimeRemaining <= 0) {
                    this.whiteTimeRemaining = 0;
                    this.endGame(1); // 白方超时，黑方胜
                }
            }
            
            this.updateTimerDisplay();
        }, 100);
    }
    
    updateTimerDisplay() {
        if (this.timerDisplay.black) {
            this.timerDisplay.black.textContent = this.blackTimeRemaining.toFixed(1) + 's';
        }
        
        if (this.timerDisplay.white) {
            this.timerDisplay.white.textContent = this.whiteTimeRemaining.toFixed(1) + 's';
        }
    }

    // 设置音效开关
    enableBackgroundMusic(enabled) {
        this.soundManager.enableBackgroundMusic(enabled);
    }
    
    enableSoundEffects(enabled) {
        this.soundManager.enableSoundEffects(enabled);
    }

    // 添加悔棋功能
    undo() {
        if (this.gameOver || !this.started || this.aiThinking) return false;
        if (this.undoCount >= this.maxUndoCount) {
            alert(`悔棋次数已用完，每局限制${this.maxUndoCount}次悔棋`);
            return false;
        }
        
        // 检查是否有足够的历史记录
        if (this.board.history.length < 1) {
            console.log("没有历史记录可以悔棋");
            return false;
        }
        
        console.log("开始悔棋，当前历史记录数:", this.board.history.length);
        console.log("当前棋盘状态:", JSON.stringify(this.board.grid));
        
        let undoSuccess = false;
        
        try {
            // AI模式下，需要悔棋两次（玩家和AI的棋都悔掉）
            if (this.aiEnabled && this.board.history.length >= 2) {
                console.log("AI模式悔棋");
                
                // 保存当前棋盘状态
                const backupGrid = JSON.parse(JSON.stringify(this.board.grid));
                const backupHistory = JSON.parse(JSON.stringify(this.board.history));
                
                // 悔掉玩家的棋
                if (this.board.undo()) {
                    console.log("已悔掉玩家的棋");
                    this.switchPlayer();
                    
                    // 悔掉AI的棋
                    if (this.board.undo()) {
                        console.log("已悔掉AI的棋");
                        this.switchPlayer();
                        undoSuccess = true;
                    } else {
                        console.log("悔掉AI的棋失败，恢复状态");
                        // 悔掉AI的棋失败，恢复棋盘状态
                        this.board.grid = backupGrid;
                        this.board.history = backupHistory;
                        this.switchPlayer(); // 把玩家切换回来
                        return false;
                    }
                } else {
                    console.log("悔掉玩家的棋失败");
                    return false;
                }
            } else {
                // 人人对战模式，或者历史记录只有一步
                console.log("人人对战模式悔棋");
                if (this.board.undo()) {
                    console.log("悔棋成功");
                    this.switchPlayer();
                    undoSuccess = true;
                } else {
                    console.log("悔棋失败");
                }
            }
            
            if (undoSuccess) {
                // 增加悔棋次数计数
                this.undoCount++;
                
                // 更新悔棋按钮状态
                this.updateUndoButton();
                
                // 重置游戏状态
                this.gameOver = false;
                
                // 更新玩家回合显示
                const playerTurnElement = document.getElementById('player-turn');
                if (playerTurnElement) {
                    playerTurnElement.textContent = `轮到: ${this.currentPlayer === 1 ? '黑子' : '白子'}`;
                }
                
                // 重置并启动计时器
                if (this.timerEnabled) {
                    this.resetTimer();
                    this.startTimer();
                }
                
                console.log(`悔棋后剩余历史记录数: ${this.board.history.length}`);
                console.log("悔棋后的棋盘状态:", JSON.stringify(this.board.grid));
                
                // 清空并重绘整个棋盘和棋子
                setTimeout(() => {
                    this.redrawBoard();
                }, 0);
            }
            
            return undoSuccess;
        } catch (error) {
            console.error("悔棋过程中出错:", error);
            return false;
        }
    }
    
    // 更新悔棋按钮状态
    updateUndoButton() {
        const undoButton = document.getElementById('undo');
        if (undoButton) {
            if (this.undoCount >= this.maxUndoCount) {
                undoButton.disabled = true;
                undoButton.textContent = `悔棋(0/${this.maxUndoCount})`;
            } else {
                undoButton.disabled = false;
                undoButton.textContent = `悔棋(${this.maxUndoCount - this.undoCount}/${this.maxUndoCount})`;
            }
        }
    }
    
    // 停止计时器
    stopTimer() {
        if (this.timerInterval) {
            clearInterval(this.timerInterval);
            this.timerInterval = null;
        }
    }

    // 重新绘制整个棋盘和棋子
    redrawBoard() {
        console.log("开始重绘棋盘和棋子");
        
        try {
            // 清除可能已经存在的棋盘和棋子
            this.board.drawBoard();
            
            // 等待棋盘绘制完成
            setTimeout(() => {
                // 绘制所有棋子
                if (this.board.history && this.board.history.length > 0) {
                    console.log(`重绘${this.board.history.length}个棋子`);
                    
                    // 打印当前历史和棋盘状态
                    console.log("历史记录:", JSON.stringify(this.board.history));
                    console.log("棋盘状态:", JSON.stringify(this.board.grid));
                    
                    // 重绘所有棋子
                    this.board.history.forEach((move, index) => {
                        if (move && typeof move.x === 'number' && typeof move.y === 'number' && 
                            move.x >= 0 && move.x < this.board.size && 
                            move.y >= 0 && move.y < this.board.size) {
                            console.log(`绘制第${index+1}个棋子:`, move);
                            this.board.drawStone(move.x, move.y, move.type, index + 1);
                        } else {
                            console.error(`无效的棋子记录: ${JSON.stringify(move)}`);
                        }
                    });
                    
                    // 高亮最后一步
                    if (this.board.history.length > 0) {
                        this.board.highlightLastMove();
                    }
                } else {
                    console.log("没有棋子需要绘制");
                }
            }, 50);
        } catch (error) {
            console.error("重绘棋盘时出错:", error);
        }
    }
} 