/**
 * 音效管理器类
 * 用于控制游戏中的背景音乐
 */
class SoundManager {
    constructor() {
        this.sounds = {};
        this.bgMusic = null;
        this.isMuted = false;
        this.bgMusicVolume = 0.3;
        
        // 从本地存储加载设置
        const bgMusicEnabled = localStorage.getItem('bgMusicEnabled') !== 'false';
        this.isMuted = !bgMusicEnabled;
        
        // 预加载音效
        this.preload();
        
        // 监听设置面板的开关变化
        this.setupListeners();
    }
    
    setupListeners() {
        const bgMusicToggle = document.getElementById('bg-music-toggle');
        
        if (bgMusicToggle) {
            bgMusicToggle.addEventListener('change', () => {
                this.setMute(!bgMusicToggle.checked);
                localStorage.setItem('bgMusicEnabled', bgMusicToggle.checked);
            });
        }
    }
    
    preload() {
        try {
            // 背景音乐 - 尝试多个地址
            if (!this.loadSound('bgMusic', 'scenery.mp3')) {
                if (!this.loadSound('bgMusic', 'assets/sounds/background.mp3')) {
                    // 如果两者都失败，使用一个硬编码的网络音频地址
                    this.loadSound('bgMusic', 'https://vgmsite.com/soundtracks/zelda-links-awakening/hpztvnfzsv/2-04.%20Mysterious%20Forest.mp3');
                }
            }
        } catch (error) {
            console.error('加载音效时出错:', error);
        }
    }
    
    loadSound(name, path) {
        try {
            const audio = new Audio();
            audio.src = path;
            audio.preload = 'auto';
            
            // 捕获加载错误
            audio.addEventListener('error', (e) => {
                console.warn(`Failed to load sound: ${path}`, e);
                audio.error = true;
            });
            
            // 存储音频对象
            this.sounds[name] = audio;
            
            // 特殊处理背景音乐
            if (name === 'bgMusic') {
                this.bgMusic = audio;
                this.bgMusic.loop = true;
                this.bgMusic.volume = this.bgMusicVolume;
                
                // 监听音频可以播放的事件
                audio.addEventListener('canplaythrough', () => {
                    console.log(`背景音乐已加载完成: ${path}`);
                    audio.loaded = true;
                });
            }
            
            return !audio.error;
        } catch (error) {
            console.error(`Failed to create audio for ${name}:`, error);
            return false;
        }
    }
    
    // 播放背景音乐
    playBgMusic() {
        if (!this.bgMusic || this.isMuted) return;
        
        try {
            // 重置音乐
            if (this.bgMusic.currentTime > 0) {
                this.bgMusic.currentTime = 0;
            }
            
            // 设置音量
            this.bgMusic.volume = this.bgMusicVolume;
            
            // 尝试播放
            const playPromise = this.bgMusic.play();
            
            // 处理自动播放的限制
            if (playPromise !== undefined) {
                playPromise.catch(e => {
                    console.warn('Background music autoplay failed:', e);
                    
                    // 添加用户交互时自动播放的事件监听
                    const playOnInteraction = () => {
                        const newPromise = this.bgMusic.play();
                        newPromise.catch(err => {
                            console.warn('Play on interaction failed:', err);
                        });
                        document.removeEventListener('click', playOnInteraction);
                    };
                    document.addEventListener('click', playOnInteraction);
                });
            }
        } catch (error) {
            console.error('播放背景音乐时出错:', error);
        }
    }
    
    // 暂停背景音乐
    pauseBgMusic() {
        if (this.bgMusic) {
            try {
                this.bgMusic.pause();
            } catch (error) {
                console.error('暂停背景音乐时出错:', error);
            }
        }
    }
    
    // 设置静音状态
    setMute(muted) {
        this.isMuted = muted;
        
        if (muted) {
            this.pauseBgMusic();
        } else {
            this.playBgMusic();
        }
    }
    
    // 切换静音/取消静音
    toggleMute() {
        this.setMute(!this.isMuted);
        return this.isMuted;
    }
    
    // 设置背景音乐音量
    setBgMusicVolume(volume) {
        this.bgMusicVolume = Math.max(0, Math.min(1, volume));
        if (this.bgMusic) {
            this.bgMusic.volume = this.bgMusicVolume;
        }
    }
    
    // 保留这些方法以兼容现有代码，但不执行任何操作
    playStoneSound() {}
    playWinSound() {}
    playDrawSound() {}
    playLoseSound() {}
    setSfxVolume() {}
    enableSoundEffects() {}
} 