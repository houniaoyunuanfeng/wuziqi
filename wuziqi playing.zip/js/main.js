document.addEventListener('DOMContentLoaded', () => {
    // 获取DOM元素
    const menuElement = document.getElementById('menu');
    const gameBoardElement = document.getElementById('game-board');
    const difficultySelectElement = document.getElementById('difficulty-select');
    const settingsPanelElement = document.getElementById('settings-panel');
    
    // 按钮元素
    const standardModeButton = document.getElementById('standard-mode');
    const settingsButton = document.getElementById('settings');
    const backToMenuButton = document.getElementById('back-to-menu');
    const restartButton = document.getElementById('restart');
    const backFromDifficultyButton = document.getElementById('back-from-difficulty');
    const backFromSettingsButton = document.getElementById('back-from-settings');
    const undoButton = document.getElementById('undo');
    
    // 音频设置元素
    const bgMusicToggle = document.getElementById('bg-music-toggle');
    
    // 游戏逻辑实例
    let game = null;
    
    // 延迟初始化游戏实例
    function initGame() {
        if (!game) {
            game = new Game('board', 1);
        }
        return game;
    }
    
    // 绑定主菜单按钮事件
    standardModeButton.addEventListener('click', () => {
        menuElement.classList.add('hidden');
        difficultySelectElement.classList.remove('hidden');
    });
    
    settingsButton.addEventListener('click', () => {
        menuElement.classList.add('hidden');
        settingsPanelElement.classList.remove('hidden');
    });
    
    // 绑定游戏界面按钮事件
    backToMenuButton.addEventListener('click', () => {
        if (game) {
            game.stopTimer();
        }
        gameBoardElement.classList.add('hidden');
        menuElement.classList.remove('hidden');
    });
    
    restartButton.addEventListener('click', () => {
        const gameInstance = initGame();
        
        // 清除可能存在的游戏结果层
        const oldOverlay = document.getElementById('game-result-overlay');
        if (oldOverlay) {
            oldOverlay.remove();
        }
        
        gameInstance.startGame();
    });
    
    // 绑定悔棋按钮
    undoButton.addEventListener('click', () => {
        if (undoButton.disabled) return;
        const gameInstance = initGame();
        if (gameInstance.undo()) {
            console.log('悔棋成功');
        } else {
            console.log('无法悔棋');
        }
    });
    
    // 绑定难度选择界面按钮事件
    document.querySelectorAll('.difficulty-buttons button').forEach(button => {
        button.addEventListener('click', () => {
            const difficulty = parseInt(button.getAttribute('data-difficulty'));
            startStandardGame(difficulty);
        });
    });
    
    backFromDifficultyButton.addEventListener('click', () => {
        difficultySelectElement.classList.add('hidden');
        menuElement.classList.remove('hidden');
    });
    
    // 绑定设置界面按钮事件
    backFromSettingsButton.addEventListener('click', () => {
        settingsPanelElement.classList.add('hidden');
        menuElement.classList.remove('hidden');
    });
    
    // 音频设置事件
    bgMusicToggle.addEventListener('change', () => {
        const enabled = bgMusicToggle.checked;
        localStorage.setItem('bgMusicEnabled', enabled);
        
        // 如果游戏已初始化，则立即应用设置
        if (game) {
            game.soundManager.setMute(!enabled);
        }
    });
    
    // 开始标准游戏
    function startStandardGame(difficulty) {
        difficultySelectElement.classList.add('hidden');
        gameBoardElement.classList.remove('hidden');
        const gameInstance = initGame();
        
        // 清除可能存在的游戏结果层
        const oldOverlay = document.getElementById('game-result-overlay');
        if (oldOverlay) {
            oldOverlay.remove();
        }
        
        // 随机决定AI是黑棋还是白棋
        const aiIsBlack = Math.random() < 0.5;
        const aiPlayer = aiIsBlack ? 1 : 2;
        
        // 配置游戏
        gameInstance.setAILevel(difficulty);
        gameInstance.setAIPlayer(aiPlayer);
        
        // 显示难度
        document.getElementById('difficulty-display').classList.remove('hidden');
        document.getElementById('difficulty-display').textContent = `难度: ${difficulty} (AI: ${aiIsBlack ? '黑棋' : '白棋'})`;
        
        // 初始化悔棋按钮
        if (undoButton) {
            undoButton.disabled = false;
            undoButton.textContent = `悔棋(${gameInstance.maxUndoCount}/${gameInstance.maxUndoCount})`;
        }
        
        // 使用setTimeout让UI更新先完成
        setTimeout(() => {
            gameInstance.startGame();
        }, 0);
    }
    
    // 从本地存储加载设置
    function loadSettings() {
        const bgMusicEnabled = localStorage.getItem('bgMusicEnabled') !== 'false';
        bgMusicToggle.checked = bgMusicEnabled;
    }
    
    // 添加页面可见性变更监听，在页面不可见时暂停计时器
    document.addEventListener('visibilitychange', () => {
        if (game) {
            if (document.hidden) {
                game.stopTimer();
            } else if (game.started && !game.gameOver) {
                game.startTimer();
            }
        }
    });
    
    // 监听窗口大小变化，重新适应棋盘
    let resizeTimeout;
    window.addEventListener('resize', () => {
        // 使用防抖处理避免频繁触发
        clearTimeout(resizeTimeout);
        resizeTimeout = setTimeout(() => {
            if (game && game.board) {
                // 重绘棋盘及棋子
                game.board.drawBoard();
                // 重新绘制棋子和步数
                game.board.history.forEach((move, index) => {
                    game.board.drawStone(move.x, move.y, move.type, index + 1);
                });
                // 高亮最后一步
                game.board.highlightLastMove();
            }
        }, 100);
    });
    
    // 加载设置
    loadSettings();
}); 