/**
 * AI类，负责电脑落子逻辑
 */
class AI {
    constructor(board, difficulty = 1) {
        this.board = board;
        this.difficulty = difficulty;
    }
    
    /**
     * 在指定难度下找出最佳落子位置
     * @param {number} playerType 1=黑子，2=白子
     * @returns {object} 包含x和y坐标的对象
     */
    findBestMove(playerType) {
        const opponentType = playerType === 1 ? 2 : 1;
        
        // 根据难度选择不同的AI策略
        switch (this.difficulty) {
            case 1: // 入门
                return this.getBasicMove(playerType, opponentType);
            case 2: // 初级
                return this.getIntermediateMove(playerType, opponentType, 1);
            case 3: // 中级
                return this.getIntermediateMove(playerType, opponentType, 2);
            case 4: // 高级
                return this.getAdvancedMove(playerType, opponentType, 2);
            case 5: // 专家
                return this.getAdvancedMove(playerType, opponentType, 3);
            default:
                return this.getBasicMove(playerType, opponentType);
        }
    }
    
    /**
     * 入门级AI - 随机+基础进攻防守
     */
    getBasicMove(playerType, opponentType) {
        // 检查是否有可以直接获胜的位置
        const winMove = this.findWinningMove(playerType);
        if (winMove) return winMove;
        
        // 检查是否需要防守对方即将获胜的位置
        const blockMove = this.findWinningMove(opponentType);
        if (blockMove) return blockMove;
        
        // 如果是第一步，通常落在天元（中心点）
        if (this.board.history.length === 0) {
            return { x: Math.floor(this.board.size / 2), y: Math.floor(this.board.size / 2) };
        }
        
        // 获取棋盘上所有合理的可下位置
        const availableMoves = this.getReasonableMoves();
        
        // 如果没有可下的位置，返回null
        if (availableMoves.length === 0) return null;
        
        // 随机选择一个位置
        return availableMoves[Math.floor(Math.random() * availableMoves.length)];
    }
    
    /**
     * 中级AI - 简单评估
     */
    getIntermediateMove(playerType, opponentType, depth) {
        // 检查是否有可以直接获胜的位置
        const winMove = this.findWinningMove(playerType);
        if (winMove) return winMove;
        
        // 检查是否需要防守对方即将获胜的位置
        const blockMove = this.findWinningMove(opponentType);
        if (blockMove) return blockMove;
        
        // 获取棋盘上所有合理的可下位置
        const availableMoves = this.getReasonableMoves();
        
        // 如果没有可下的位置，返回null
        if (availableMoves.length === 0) return null;
        
        // 评估每个位置的分数
        let bestScore = -Infinity;
        let bestMoves = [];
        
        for (const move of availableMoves) {
            // 模拟下棋
            this.board.grid[move.y][move.x] = playerType;
            
            // 评估分数
            const score = this.evaluatePosition(move.x, move.y, playerType, opponentType, depth);
            
            // 撤销模拟
            this.board.grid[move.y][move.x] = 0;
            
            // 更新最佳分数和位置
            if (score > bestScore) {
                bestScore = score;
                bestMoves = [move];
            } else if (score === bestScore) {
                bestMoves.push(move);
            }
        }
        
        // 从最佳位置中随机选择一个（避免AI总是选择相同的位置）
        return bestMoves[Math.floor(Math.random() * bestMoves.length)];
    }
    
    /**
     * 高级AI - 使用极小化极大算法
     */
    getAdvancedMove(playerType, opponentType, depth) {
        // 检查是否有可以直接获胜的位置
        const winMove = this.findWinningMove(playerType);
        if (winMove) return winMove;
        
        // 检查是否需要防守对方即将获胜的位置
        const blockMove = this.findWinningMove(opponentType);
        if (blockMove) return blockMove;
        
        // 获取棋盘上所有合理的可下位置
        const availableMoves = this.getReasonableMoves();
        
        // 如果没有可下的位置，返回null
        if (availableMoves.length === 0) return null;
        
        // 评估每个位置的分数
        let bestScore = -Infinity;
        let bestMoves = [];
        
        // 使用Alpha-Beta剪枝的Minimax算法
        for (const move of availableMoves) {
            // 模拟下棋
            this.board.grid[move.y][move.x] = playerType;
            
            // 评估分数（通过minimax）
            const score = this.minimax(depth, false, -Infinity, Infinity, playerType, opponentType);
            
            // 撤销模拟
            this.board.grid[move.y][move.x] = 0;
            
            // 更新最佳分数和位置
            if (score > bestScore) {
                bestScore = score;
                bestMoves = [move];
            } else if (score === bestScore) {
                bestMoves.push(move);
            }
        }
        
        // 从最佳位置中随机选择一个（避免AI总是选择相同的位置）
        return bestMoves[Math.floor(Math.random() * bestMoves.length)];
    }
    
    /**
     * 极小化极大算法（带Alpha-Beta剪枝）
     */
    minimax(depth, isMaximizing, alpha, beta, playerType, opponentType) {
        // 基础情况：达到最大深度
        if (depth === 0) {
            return this.evaluateBoardState(playerType, opponentType);
        }
        
        // 获取可用的移动位置
        const availableMoves = this.getReasonableMoves();
        
        // 如果没有可用移动，返回当前局面评分
        if (availableMoves.length === 0) {
            return this.evaluateBoardState(playerType, opponentType);
        }
        
        if (isMaximizing) {
            let maxEval = -Infinity;
            for (const move of availableMoves) {
                // 模拟AI下棋
                this.board.grid[move.y][move.x] = playerType;
                
                // 递归评估
                const evalScore = this.minimax(depth - 1, false, alpha, beta, playerType, opponentType);
                
                // 撤销模拟
                this.board.grid[move.y][move.x] = 0;
                
                // 更新最大评分和Alpha值
                maxEval = Math.max(maxEval, evalScore);
                alpha = Math.max(alpha, evalScore);
                
                // Alpha-Beta剪枝
                if (beta <= alpha) break;
            }
            return maxEval;
        } else {
            let minEval = Infinity;
            for (const move of availableMoves) {
                // 模拟对手下棋
                this.board.grid[move.y][move.x] = opponentType;
                
                // 递归评估
                const evalScore = this.minimax(depth - 1, true, alpha, beta, playerType, opponentType);
                
                // 撤销模拟
                this.board.grid[move.y][move.x] = 0;
                
                // 更新最小评分和Beta值
                minEval = Math.min(minEval, evalScore);
                beta = Math.min(beta, evalScore);
                
                // Alpha-Beta剪枝
                if (beta <= alpha) break;
            }
            return minEval;
        }
    }
    
    /**
     * 获取棋盘上所有合理的可下位置
     */
    getReasonableMoves() {
        const moves = [];
        const checked = Array(this.board.size).fill().map(() => Array(this.board.size).fill(false));
        
        // 检查每个已有棋子的周围
        for (let y = 0; y < this.board.size; y++) {
            for (let x = 0; x < this.board.size; x++) {
                if (this.board.grid[y][x] !== 0) { // 已有棋子
                    // 检查周围2格范围内的空位
                    for (let dy = -2; dy <= 2; dy++) {
                        for (let dx = -2; dx <= 2; dx++) {
                            const nx = x + dx;
                            const ny = y + dy;
                            
                            // 检查边界和是否已检查过
                            if (nx >= 0 && nx < this.board.size && ny >= 0 && ny < this.board.size && 
                                !checked[ny][nx] && this.board.grid[ny][nx] === 0) {
                                moves.push({x: nx, y: ny});
                                checked[ny][nx] = true;
                            }
                        }
                    }
                }
            }
        }
        
        // 如果没有合理位置，则返回所有可用位置的中央位置
        if (moves.length === 0) {
            const center = Math.floor(this.board.size / 2);
            if (this.board.grid[center][center] === 0) {
                moves.push({x: center, y: center});
            } else {
                // 获取所有空位
                for (let y = 0; y < this.board.size; y++) {
                    for (let x = 0; x < this.board.size; x++) {
                        if (this.board.grid[y][x] === 0) {
                            moves.push({x, y});
                        }
                    }
                }
            }
        }
        
        return moves;
    }
    
    /**
     * 查找是否有直接获胜的位置
     */
    findWinningMove(stoneType) {
        const availableMoves = this.getReasonableMoves();
        
        for (const move of availableMoves) {
            // 模拟下棋
            this.board.grid[move.y][move.x] = stoneType;
            
            // 检查是否获胜
            const isWinning = this.board.checkWin(move.x, move.y, stoneType);
            
            // 撤销模拟
            this.board.grid[move.y][move.x] = 0;
            
            if (isWinning) {
                return move;
            }
        }
        
        return null;
    }
    
    /**
     * 评估特定位置的分数
     */
    evaluatePosition(x, y, playerType, opponentType, depth) {
        let score = 0;
        
        // 检查连线
        const directions = [
            {x: 1, y: 0},  // 水平
            {x: 0, y: 1},  // 垂直
            {x: 1, y: 1},  // 右下
            {x: 1, y: -1}  // 右上
        ];
        
        for (const dir of directions) {
            // 评估AI方的连线
            score += this.evaluateLine(x, y, dir.x, dir.y, playerType) * 10;
            
            // 评估对手方的连线（防守价值）
            score += this.evaluateLine(x, y, dir.x, dir.y, opponentType) * 8;
        }
        
        // 根据位置给予额外分数（中央位置更优）
        const center = Math.floor(this.board.size / 2);
        const distanceToCenter = Math.abs(x - center) + Math.abs(y - center);
        score -= distanceToCenter * 2;
        
        // 根据深度增加随机性（避免AI行为过于机械）
        if (depth > 0) {
            score += Math.random() * 3;
        }
        
        return score;
    }
    
    /**
     * 评估整个棋盘状态
     */
    evaluateBoardState(playerType, opponentType) {
        let score = 0;
        
        // 检查所有已经存在的棋子
        for (let y = 0; y < this.board.size; y++) {
            for (let x = 0; x < this.board.size; x++) {
                if (this.board.grid[y][x] === playerType) {
                    // 评估AI方棋子的价值
                    score += this.evaluateStoneValue(x, y, playerType);
                } else if (this.board.grid[y][x] === opponentType) {
                    // 评估对手方棋子的威胁
                    score -= this.evaluateStoneValue(x, y, opponentType);
                }
            }
        }
        
        return score;
    }
    
    /**
     * 评估单个棋子的价值
     */
    evaluateStoneValue(x, y, stoneType) {
        let value = 0;
        
        // 检查连线
        const directions = [
            {x: 1, y: 0},  // 水平
            {x: 0, y: 1},  // 垂直
            {x: 1, y: 1},  // 右下
            {x: 1, y: -1}  // 右上
        ];
        
        for (const dir of directions) {
            value += this.evaluateLine(x, y, dir.x, dir.y, stoneType);
        }
        
        return value;
    }
    
    /**
     * 评估特定方向的连线
     */
    evaluateLine(x, y, dx, dy, stoneType) {
        const patterns = {
            five: 100000,    // 五连（胜利）
            openFour: 10000, // 活四
            fourThree: 5000, // 四三
            closedFour: 1000, // 冲四
            openThree: 500,  // 活三
            closedThree: 100, // 眠三
            openTwo: 50,     // 活二
            closedTwo: 10    // 眠二
        };
        
        // 记录连续棋子数
        let count = 1;
        let open = 0; // 记录开口数
        
        // 正方向搜索
        for (let i = 1; i <= 4; i++) {
            const nx = x + dx * i;
            const ny = y + dy * i;
            
            if (nx < 0 || nx >= this.board.size || ny < 0 || ny >= this.board.size) {
                break;
            }
            
            if (this.board.grid[ny][nx] === stoneType) {
                count++;
            } else if (this.board.grid[ny][nx] === 0) {
                open++;
                break;
            } else {
                break;
            }
        }
        
        // 反方向搜索
        for (let i = 1; i <= 4; i++) {
            const nx = x - dx * i;
            const ny = y - dy * i;
            
            if (nx < 0 || nx >= this.board.size || ny < 0 || ny >= this.board.size) {
                break;
            }
            
            if (this.board.grid[ny][nx] === stoneType) {
                count++;
            } else if (this.board.grid[ny][nx] === 0) {
                open++;
                break;
            } else {
                break;
            }
        }
        
        // 根据连续棋子数和开口数返回分数
        if (count >= 5) return patterns.five;
        if (count === 4) {
            if (open === 2) return patterns.openFour;
            if (open === 1) return patterns.closedFour;
        }
        if (count === 3) {
            if (open === 2) return patterns.openThree;
            if (open === 1) return patterns.closedThree;
        }
        if (count === 2) {
            if (open === 2) return patterns.openTwo;
            if (open === 1) return patterns.closedTwo;
        }
        
        return 0;
    }
} 